<?php

	function cetak($str){
		echo htmlentities($str, ENT_QUOTES, 'UTF-8');
	}

?>