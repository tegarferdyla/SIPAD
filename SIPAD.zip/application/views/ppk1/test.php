<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
	<div class="row">
		<div class="col-sm-6">
			<div class="pos-relative" style="height: 200px">
				<canvas id="chartkurs"></canvas><span class="h6 fw-600 text-muted fs-13 text-uppercase m-0 absolute-center">Prosentase</span>
			</div>
		</div>
	</div>
