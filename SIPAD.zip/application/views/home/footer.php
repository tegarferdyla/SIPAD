 <footer class="main-footer container-fluid" style="background: url(assets/assets1/img/footer-bg.jpg);" >
      <div class="row stylefooter">
          <div class="col-md-8 col-sm-8">
            <div class="row">
              <div class="col-md-4 col-sm-4">
                <h3 class="text-warning">Situs Terkait</h3>
                <hr>
                  <ul class="list-unstyled">
                    <li class="">Situs 1</li>
                    <li>Situs 2</li>
                    <li>Situs 3</li>
                    <li>Situs 4</li>
                    <li>Situs 5</li>
                  </ul>
              </div>
              <div class="col-md-4 col-sm-4">
                <h3 class="text-warning">Aplikasi PUPR</h3>
                <hr>
                 <ul class="list-unstyled">
                  <li>Aplikasi 1</li>
                  <li>Aplikasi 2</li>
                  <li>Aplikasi 3</li>
                  <li>Aplikasi 4</li>
                  <li>Aplikasi 5</li>
                 </ul> 
              </div>
              <div class="col-md-4 col-sm-4">
                <h3 class="text-warning">Navigation</h3>
                <hr >
                <ul class="list-unstyled">
                <li>FAQ</li>
                <li>Sitemap</li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-sm-4">
                <h3 class="text-warning">Kontak Kami</h3>
                <hr>
                <ul class="list-unstyled">
                  <li>Kementrian PUPR</li>
                  <li>Jl. Pattimura No. 20 Kebayoran Baru</li>
                  <li>Jakarta Selatan 12110</li>
                  <li>(021) 7228497</li>
                </ul>
          </div>
      </div><!-- /.row -->
      <div class="row">
          <div class="col-md-12">
            <div class="copyright text-center">
              <p style="color:white">Hak Cipta &copy; 2018 <a href="https://www.instagram.com/tegarferdyla/" title="">-----</a></p>
            </div>
          </div>
        </div>

  </footer>







    <link rel="stylesheet" href="<?php echo base_url('assets/vendors/linea-icons/styles.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800,900" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
    <script src="<?php echo base_url('assets/js/custom.js') ?> "></script>
    <script src="http://localhost:35729/livereload.js"></script>
  </body>
</html>